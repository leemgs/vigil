# Experiment outputs

Original experiment logs were lost in a server failure and are not available.
No reconstructed or regenerated prediction CSVs are included in this submission.

The paper reports point estimates only. Confidence intervals, p-values, and
bootstrap statistics that depended on the lost logs have been removed from
the main text and tables. Evaluation scripts and annotation guidelines (when
released with the camera-ready) will support independent re-runs.

For review: no supplementary experiment CSVs are provided with this anonymous
submission.
