# PLRE re-experiment toolkit

Minimal scripts to regenerate the four high-priority experiments:

1. `vigil_full` vs `vigil_no_gate` + paired bootstrap CI  
2. Non-distractor subset metrics  
3. B5 (self-refinement) on PLRE  
4. `date_filter` (and optional regex-gate) baseline  

## Setup

```bash
cd plre_reexperiment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export OPENAI_API_KEY="sk-..."          # or Azure vars (see below)
# export PLRE_MODEL="gpt-4o-2024-08-06"
```

Azure:

```bash
export AZURE_OPENAI_API_KEY="..."
export AZURE_OPENAI_ENDPOINT="https://YOUR.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"
```

## Data

Put your real file at `data/plre_test.jsonl` (see `data/plre_test.example.jsonl`).

Required fields per line:

- `pair_id`, `gold` (`YES`|`NO`)
- `product_attribute`, `risk_theory`, `query_date`
- `is_stale_distractor` (bool)
- `passages`: list of `{doc_id, decision_date, text, validity_status}`
  - `validity_status` ∈ `open|closed|narrowed|cautionary`

## Run (recommended order)

Smoke test (2 example rows):

```bash
cd scripts
python run_plre_infer.py --input ../data/plre_test.example.jsonl --limit 2 --systems vigil_full,vigil_no_gate
python compute_metrics.py --pred-glob "../outputs/preds_*.jsonl"
```

Full:

```bash
# 1–2) gate / no-gate (also enables non-distractor metrics in compute_metrics)
python run_plre_infer.py --input ../data/plre_test.jsonl --systems vigil_full,vigil_no_gate

# 3) B5 on PLRE
python run_b5_plre.py --input ../data/plre_test.jsonl

# 4a) date filter
python run_plre_infer.py --input ../data/plre_test.jsonl --systems date_filter

# 4b) optional regex gate
python regex_gate_passages.py --input ../data/plre_test.jsonl --output ../data/plre_test_regex.jsonl
python run_plre_infer.py --input ../data/plre_test_regex.jsonl --systems vigil_full
# rename outputs if you need to distinguish regex vs gold intervals

# Metrics + bootstrap CI
python compute_metrics.py --pred-glob "../outputs/preds_*.jsonl" --seed 0 --n-boot 10000
```

Seeds default to `0,1,2,3,4` (`PLRE_SEEDS`). Point estimates in the paper can use `seed=0`; multi-seed means are optional.

## Outputs

- `outputs/preds_{system}_seed{k}.jsonl` — per-instance logs (keep these for the paper/CI)
- Console: P/R/F1, stale-cite, non-distractor subset, paired bootstrap 95% CI

## Notes

- Resume-safe: existing `pair_id`s in an output file are skipped.
- Do not commit API keys.
- Bit-identical reproduction needs the same model snapshot when available.
