#!/usr/bin/env bash
# Run the four priority re-experiments end-to-end.
set -euo pipefail
cd "$(dirname "$0")"

INPUT="${1:-../data/plre_test.jsonl}"
if [[ ! -f "$INPUT" ]]; then
  echo "Missing $INPUT — copy your data or use ../data/plre_test.example.jsonl"
  exit 1
fi

echo "== gate / no-gate =="
python run_plre_infer.py --input "$INPUT" --systems vigil_full,vigil_no_gate

echo "== B5 =="
python run_b5_plre.py --input "$INPUT"

echo "== date_filter =="
python run_plre_infer.py --input "$INPUT" --systems date_filter

echo "== metrics + bootstrap CI =="
python compute_metrics.py --pred-glob "../outputs/preds_*.jsonl" --seed 0 --n-boot 10000

echo "Done. Predictions in ../outputs/"
