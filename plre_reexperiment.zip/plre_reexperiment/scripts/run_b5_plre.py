#!/usr/bin/env python3
"""Iteration-matched self-refinement baseline (B5) on PLRE.

Usage:
  python run_b5_plre.py --input ../data/plre_test.jsonl
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

from config import B5_MAX_COMPLETION_TOKENS, B5_MAX_ITERS, DATA_DIR, OUT_DIR, SEEDS, TEMP_CTRL
from llm_client import chat_json, extract_label
from prompts import SYSTEM_B5, format_passages


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open() as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def run_b5(row: dict, seed: int) -> dict:
    passages = row.get("passages", [])  # no validity filter
    system = SYSTEM_B5.format(max_iters=B5_MAX_ITERS)
    history = []
    total_out = 0
    last = {}

    for it in range(1, B5_MAX_ITERS + 1):
        user = (
            f"Iteration {it}/{B5_MAX_ITERS}\n"
            f"product_attribute: {row['product_attribute']}\n"
            f"risk_theory: {row['risk_theory']}\n"
            f"query_date: {row['query_date']}\n\n"
            f"passages (ungated):\n{format_passages(passages, include_validity=False)}\n\n"
        )
        if history:
            user += "Previous draft/critique:\n" + json.dumps(history[-1], ensure_ascii=False) + "\n"
        user += (
            "Produce an updated JSON decision. On the final iteration, finalize label."
        )
        obj = chat_json(system, user, temperature=TEMP_CTRL, seed=seed + it)
        usage = obj.pop("_usage", {})
        total_out += int(usage.get("tokens_out") or 0)
        last = obj
        history.append({"iteration": it, "draft": obj, "usage": usage})
        if B5_MAX_COMPLETION_TOKENS and total_out >= B5_MAX_COMPLETION_TOKENS:
            break

    label = extract_label(last)
    return {
        "experiment": "b5_plre",
        "system": "b5",
        "pair_id": row["pair_id"],
        "dispute_id": row.get("dispute_id"),
        "seed": seed,
        "gold": str(row["gold"]).upper(),
        "pred": label,
        "confidence": last.get("confidence"),
        "stale_cited": bool(last.get("stale_cited", False)),
        "is_stale_distractor": bool(row.get("is_stale_distractor", False)),
        "iterations_used": last.get("iterations_used", len(history)),
        "tokens_out_total": total_out,
        "history": history,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, default=DATA_DIR / "plre_test.jsonl")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    rows = load_jsonl(args.input)
    if args.limit > 0:
        rows = rows[: args.limit]

    for seed in SEEDS:
        out_path = OUT_DIR / f"preds_b5_seed{seed}.jsonl"
        done = set()
        if out_path.exists():
            with out_path.open() as f:
                for line in f:
                    if line.strip():
                        done.add(json.loads(line)["pair_id"])
        mode = "a" if done else "w"
        with out_path.open(mode) as out:
            for row in tqdm(rows, desc=f"b5 seed={seed}"):
                if row["pair_id"] in done:
                    continue
                rec = run_b5(row, seed)
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                out.flush()
        print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
