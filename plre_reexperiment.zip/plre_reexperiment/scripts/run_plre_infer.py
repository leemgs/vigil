#!/usr/bin/env python3
"""Run VIGIL_full (gated) and VIGIL_no_gate (ungated) on PLRE test pairs.

Usage:
  export OPENAI_API_KEY=sk-...
  python run_plre_infer.py --input ../data/plre_test.jsonl --systems vigil_full,vigil_no_gate

Output:
  ../outputs/preds_{system}_seed{seed}.jsonl
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

from config import DATA_DIR, OUT_DIR, SEEDS, TEMP_CTRL
from llm_client import chat_json, extract_label
from prompts import SYSTEM_PLRE, SYSTEM_PLRE_DATE_ONLY, user_plre


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def filter_passages(passages: list[dict], system: str) -> list[dict]:
    if system == "vigil_full":
        return [p for p in passages if p.get("validity_status") != "closed"]
    if system == "date_filter":
        # caller should already date-filter; keep all provided
        return passages
    # vigil_no_gate, regex_gate (status already set by caller), etc.
    return passages


def date_filter_passages(row: dict) -> list[dict]:
    tq = row["query_date"]
    return [p for p in row.get("passages", []) if str(p.get("decision_date", "")) <= str(tq)]


def run_one(row: dict, system: str, seed: int) -> dict:
    passages = row.get("passages", [])
    include_validity = True
    system_prompt = SYSTEM_PLRE

    if system == "date_filter":
        passages = date_filter_passages(row)
        include_validity = False
        system_prompt = SYSTEM_PLRE_DATE_ONLY
    else:
        passages = filter_passages(passages, system)

    user = user_plre(row, passages, include_validity=include_validity)
    obj = chat_json(system_prompt, user, temperature=TEMP_CTRL, seed=seed)
    label = extract_label(obj)
    usage = obj.pop("_usage", {})
    return {
        "experiment": "plre_infer",
        "system": system,
        "pair_id": row["pair_id"],
        "dispute_id": row.get("dispute_id"),
        "seed": seed,
        "gold": str(row["gold"]).upper(),
        "pred": label,
        "confidence": obj.get("confidence"),
        "stale_cited": bool(obj.get("stale_cited", False)),
        "is_stale_distractor": bool(row.get("is_stale_distractor", False)),
        "supporting_doc_ids": obj.get("supporting_doc_ids"),
        "n_passages_used": len(passages),
        **usage,
        "model_raw": {k: v for k, v in obj.items() if not k.startswith("_")},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, default=DATA_DIR / "plre_test.jsonl")
    ap.add_argument(
        "--systems",
        default="vigil_full,vigil_no_gate",
        help="Comma list: vigil_full,vigil_no_gate,date_filter",
    )
    ap.add_argument("--limit", type=int, default=0, help="If >0, only first N pairs (smoke test)")
    args = ap.parse_args()

    rows = load_jsonl(args.input)
    if args.limit > 0:
        rows = rows[: args.limit]
    systems = [s.strip() for s in args.systems.split(",") if s.strip()]

    for system in systems:
        for seed in SEEDS:
            out_path = OUT_DIR / f"preds_{system}_seed{seed}.jsonl"
            # resume-friendly: skip existing pair_ids
            done = set()
            if out_path.exists():
                with out_path.open() as f:
                    for line in f:
                        if line.strip():
                            done.add(json.loads(line)["pair_id"])
            mode = "a" if done else "w"
            with out_path.open(mode) as out:
                for row in tqdm(rows, desc=f"{system} seed={seed}"):
                    if row["pair_id"] in done:
                        continue
                    rec = run_one(row, system, seed)
                    out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    out.flush()
            print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
