"""Prompt templates for PLRE re-experiments."""
from __future__ import annotations

from typing import Any

SYSTEM_PLRE = """You are a legal-risk entailment classifier for AI products.

Decide whether a product_attribute entails exposure to a risk_theory under
authorities that are legally operative at query_date.

Rules:
- Only passages whose validity_status is open, narrowed, or cautionary may support YES.
- Passages marked closed must not support a positive decision (they may still appear as context).
- If evidence is insufficient, answer NO.
- Respond with a single JSON object only:
  {"label": "YES"|"NO", "confidence": 0.0-1.0, "supporting_doc_ids": ["..."],
   "stale_cited": true|false}
- stale_cited=true if your reasoning relies on a closed authority.
"""

SYSTEM_PLRE_DATE_ONLY = """You are a legal-risk entailment classifier for AI products.

Passages were filtered only by document date (decision_date <= query_date).
There is NO supersession / overruling metadata beyond what appears in the text.

Decide whether product_attribute entails exposure to risk_theory at query_date.
Respond with JSON only:
{"label": "YES"|"NO", "confidence": 0.0-1.0, "stale_cited": true|false}
"""

SYSTEM_B5 = """You are a self-refining legal-risk analyst (Reflexion-style).

You will run up to {max_iters} iterations. Each iteration:
1) Propose YES/NO on whether product_attribute entails risk_theory at query_date.
2) Critique gaps (missing evidence, possible stale authority, weak alignment).
3) Revise.

Retrieved passages are provided WITHOUT validity gating (flat RAG).

After the final iteration, respond with JSON only:
{"label": "YES"|"NO", "confidence": 0.0-1.0, "iterations_used": <int>,
 "stale_cited": true|false, "rationale": "<one sentence>"}
"""


def format_passages(passages: list[dict[str, Any]], include_validity: bool = True) -> str:
    lines = []
    for i, p in enumerate(passages, 1):
        vs = p.get("validity_status", "unknown")
        if include_validity:
            header = f"[{i}] doc_id={p.get('doc_id')} date={p.get('decision_date')} validity={vs}"
        else:
            header = f"[{i}] doc_id={p.get('doc_id')} date={p.get('decision_date')}"
        lines.append(header)
        lines.append(str(p.get("text", ""))[:2000])
        lines.append("")
    return "\n".join(lines).strip()


def user_plre(row: dict[str, Any], passages: list[dict[str, Any]], include_validity: bool) -> str:
    return (
        f"product_attribute: {row['product_attribute']}\n"
        f"risk_theory: {row['risk_theory']}\n"
        f"query_date: {row['query_date']}\n\n"
        f"passages:\n{format_passages(passages, include_validity=include_validity)}"
    )
