#!/usr/bin/env python3
"""Metrics + paired bootstrap CI from per-instance prediction JSONL files.

Usage:
  python compute_metrics.py --pred-glob "../outputs/preds_*.jsonl"

Prints:
  - macro/binary F1, precision, recall per system (seed-averaged or seed=0)
  - stale-cite rate
  - non-distractor subset metrics
  - paired bootstrap 95% CI for F1(system_a) - F1(system_b)
"""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score, precision_score, recall_score


def load_preds(paths: list[Path]) -> list[dict]:
    rows = []
    for p in paths:
        with p.open() as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    return rows


def binary_f1(y_true: list[str], y_pred: list[str]) -> float:
    yt = [1 if y == "YES" else 0 for y in y_true]
    yp = [1 if y == "YES" else 0 for y in y_pred]
    return float(f1_score(yt, yp, zero_division=0))


def prf(y_true: list[str], y_pred: list[str]) -> tuple[float, float, float]:
    yt = [1 if y == "YES" else 0 for y in y_true]
    yp = [1 if y == "YES" else 0 for y in y_pred]
    p = float(precision_score(yt, yp, zero_division=0))
    r = float(recall_score(yt, yp, zero_division=0))
    f = float(f1_score(yt, yp, zero_division=0))
    return p, r, f


def summarize(rows: list[dict], label: str) -> None:
    if not rows:
        print(f"[{label}] empty")
        return
    yt = [r["gold"] for r in rows]
    yp = [r["pred"] for r in rows]
    p, r, f = prf(yt, yp)
    stale = np.mean([1.0 if r.get("stale_cited") else 0.0 for r in rows])
    print(
        f"[{label}] n={len(rows)}  P={p:.3f} R={r:.3f} F1={f:.3f}  "
        f"stale_cite={stale:.3f}"
    )


def paired_bootstrap_f1_delta(
    rows_a: list[dict],
    rows_b: list[dict],
    n_boot: int = 10_000,
    seed: int = 0,
) -> tuple[float, float, float]:
    """Paired by pair_id. Returns (delta, ci_low, ci_high) for F1_a - F1_b."""
    by_a = {r["pair_id"]: r for r in rows_a}
    by_b = {r["pair_id"]: r for r in rows_b}
    ids = sorted(set(by_a) & set(by_b))
    if not ids:
        raise ValueError("No overlapping pair_ids for paired bootstrap")

    ya = np.array([1 if by_a[i]["gold"] == "YES" else 0 for i in ids])
    pa = np.array([1 if by_a[i]["pred"] == "YES" else 0 for i in ids])
    pb = np.array([1 if by_b[i]["pred"] == "YES" else 0 for i in ids])
    # gold must match; use ya for both

    def f1(y, p):
        tp = np.sum((y == 1) & (p == 1))
        fp = np.sum((y == 0) & (p == 1))
        fn = np.sum((y == 1) & (p == 0))
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        return 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0

    delta = f1(ya, pa) - f1(ya, pb)
    rng = np.random.default_rng(seed)
    n = len(ids)
    boots = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boots.append(f1(ya[idx], pa[idx]) - f1(ya[idx], pb[idx]))
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return float(delta), float(lo), float(hi)


def select(rows: list[dict], system: str, seed: int | None = None) -> list[dict]:
    out = [r for r in rows if r.get("system") == system]
    if seed is not None:
        out = [r for r in out if r.get("seed") == seed]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred-glob", default="../outputs/preds_*.jsonl")
    ap.add_argument("--seed", type=int, default=0, help="Primary seed for point estimates")
    ap.add_argument("--n-boot", type=int, default=10_000)
    args = ap.parse_args()

    paths = sorted(Path().glob(args.pred_glob)) if "*" in args.pred_glob else [Path(args.pred_glob)]
    # also try from script dir relative
    if not paths:
        paths = sorted(Path(__file__).resolve().parents[1].joinpath("outputs").glob("preds_*.jsonl"))
    if not paths:
        raise SystemExit(f"No prediction files matched {args.pred_glob}")

    rows = load_preds(paths)
    systems = sorted({r["system"] for r in rows})
    print("Systems:", systems)
    print(f"Point estimates at seed={args.seed}")
    for s in systems:
        summarize(select(rows, s, args.seed), s)

    print("\nNon-distractor subset (is_stale_distractor==false)")
    for s in systems:
        sub = [r for r in select(rows, s, args.seed) if not r.get("is_stale_distractor")]
        summarize(sub, f"{s}/non_distractor")

    # Paired CI: vigil_full vs vigil_no_gate if both exist
    if "vigil_full" in systems and "vigil_no_gate" in systems:
        a = select(rows, "vigil_full", args.seed)
        b = select(rows, "vigil_no_gate", args.seed)
        delta, lo, hi = paired_bootstrap_f1_delta(a, b, n_boot=args.n_boot)
        print(
            f"\nPaired bootstrap F1(vigil_full)-F1(vigil_no_gate): "
            f"{delta:.3f}  95% CI [{lo:.3f}, {hi:.3f}]  (n_boot={args.n_boot})"
        )

    if "vigil_full" in systems and "b5" in systems:
        a = select(rows, "vigil_full", args.seed)
        b = select(rows, "b5", args.seed)
        delta, lo, hi = paired_bootstrap_f1_delta(a, b, n_boot=args.n_boot)
        print(
            f"Paired bootstrap F1(vigil_full)-F1(b5): "
            f"{delta:.3f}  95% CI [{lo:.3f}, {hi:.3f}]"
        )

    if "vigil_full" in systems and "date_filter" in systems:
        a = select(rows, "vigil_full", args.seed)
        b = select(rows, "date_filter", args.seed)
        delta, lo, hi = paired_bootstrap_f1_delta(a, b, n_boot=args.n_boot)
        print(
            f"Paired bootstrap F1(vigil_full)-F1(date_filter): "
            f"{delta:.3f}  95% CI [{lo:.3f}, {hi:.3f}]"
        )


if __name__ == "__main__":
    main()
