#!/usr/bin/env python3
"""
PLRE re-experiment toolkit (all-in-one).

Subcommands:
  infer      — vigil_full / vigil_no_gate / date_filter
  b5         — self-refinement baseline on PLRE
  regex-prep — rewrite validity_status with keyword heuristic
  metrics    — F1, non-distractor, paired bootstrap CI

Examples:
  export OPENAI_API_KEY=sk-...
  python plre_reexperiment_all_in_one.py infer --input data/plre_test.jsonl
  python plre_reexperiment_all_in_one.py b5 --input data/plre_test.jsonl
  python plre_reexperiment_all_in_one.py metrics --pred-dir outputs
"""
from __future__ import annotations

import argparse
import json
import os
import re
import time
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.metrics import f1_score, precision_score, recall_score
from tqdm import tqdm

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("PLRE_DATA_DIR", ROOT / "data"))
OUT_DIR = Path(os.environ.get("PLRE_OUT_DIR", ROOT / "outputs"))
OUT_DIR.mkdir(parents=True, exist_ok=True)

MODEL = os.environ.get("PLRE_MODEL", "gpt-4o-2024-08-06")
TEMP_EDGE = float(os.environ.get("PLRE_TEMP_EDGE", "0"))
TEMP_CTRL = float(os.environ.get("PLRE_TEMP_CTRL", "0.2"))
SEEDS = [int(x) for x in os.environ.get("PLRE_SEEDS", "0,1,2,3,4").split(",") if x.strip()]
B5_MAX_ITERS = int(os.environ.get("PLRE_B5_MAX_ITERS", "3"))
B5_MAX_TOKENS = os.environ.get("PLRE_B5_MAX_TOKENS")
B5_MAX_TOKENS = int(B5_MAX_TOKENS) if B5_MAX_TOKENS else None
MAX_RETRIES = int(os.environ.get("PLRE_MAX_RETRIES", "5"))
SLEEP_ON_ERROR = float(os.environ.get("PLRE_SLEEP_ON_ERROR", "2.0"))

# ---------------------------------------------------------------------------
# LLM client
# ---------------------------------------------------------------------------

def _client():
    from openai import OpenAI, AzureOpenAI

    if os.environ.get("AZURE_OPENAI_API_KEY") and os.environ.get("AZURE_OPENAI_ENDPOINT"):
        return AzureOpenAI(
            api_key=os.environ["AZURE_OPENAI_API_KEY"],
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        )
    if not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError("Set OPENAI_API_KEY or AZURE_OPENAI_API_KEY+ENDPOINT")
    return OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def _model_name() -> str:
    if os.environ.get("AZURE_OPENAI_API_KEY"):
        return os.environ.get("AZURE_OPENAI_DEPLOYMENT", MODEL)
    return MODEL


def chat_json(system: str, user: str, temperature: float, seed: int | None = None) -> dict[str, Any]:
    client = _client()
    kwargs: dict[str, Any] = {
        "model": _model_name(),
        "temperature": temperature,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "response_format": {"type": "json_object"},
    }
    if seed is not None:
        kwargs["seed"] = seed
    last_err: Exception | None = None
    for attempt in range(MAX_RETRIES):
        try:
            resp = client.chat.completions.create(**kwargs)
            text = resp.choices[0].message.content or "{}"
            data = json.loads(text)
            data["_usage"] = {
                "tokens_in": getattr(resp.usage, "prompt_tokens", None),
                "tokens_out": getattr(resp.usage, "completion_tokens", None),
            }
            return data
        except Exception as e:  # noqa: BLE001
            last_err = e
            if "seed" in kwargs and "seed" in str(e).lower():
                kwargs.pop("seed", None)
            time.sleep(SLEEP_ON_ERROR * (attempt + 1))
    raise RuntimeError(f"LLM failed: {last_err}")


def extract_label(obj: dict[str, Any]) -> str:
    lab = str(obj.get("label", "")).strip().upper()
    if lab in {"YES", "NO"}:
        return lab
    m = re.search(r"\b(YES|NO)\b", lab)
    return m.group(1) if m else "NO"

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------
SYSTEM_PLRE = """You are a legal-risk entailment classifier for AI products.

Decide whether a product_attribute entails exposure to a risk_theory under
authorities that are legally operative at query_date.

Rules:
- Only passages whose validity_status is open, narrowed, or cautionary may support YES.
- Passages marked closed must not support a positive decision.
- If evidence is insufficient, answer NO.
- Respond with JSON only:
  {"label": "YES"|"NO", "confidence": 0.0-1.0, "supporting_doc_ids": ["..."],
   "stale_cited": true|false}
- stale_cited=true if your reasoning relies on a closed authority.
"""

SYSTEM_PLRE_DATE_ONLY = """You are a legal-risk entailment classifier for AI products.

Passages were filtered only by document date (decision_date <= query_date).
There is NO supersession metadata beyond the text itself.

Decide whether product_attribute entails risk_theory at query_date.
JSON only: {"label": "YES"|"NO", "confidence": 0.0-1.0, "stale_cited": true|false}
"""

SYSTEM_B5 = """You are a self-refining legal-risk analyst (Reflexion-style).

Up to {max_iters} iterations. Each iteration: draft YES/NO, critique, revise.
Passages are UNGATED flat RAG (no validity filter).

Final JSON only:
{"label": "YES"|"NO", "confidence": 0.0-1.0, "iterations_used": <int>,
 "stale_cited": true|false, "rationale": "<one sentence>"}
"""


def format_passages(passages: list[dict[str, Any]], include_validity: bool = True) -> str:
    lines = []
    for i, p in enumerate(passages, 1):
        if include_validity:
            header = f"[{i}] doc_id={p.get('doc_id')} date={p.get('decision_date')} validity={p.get('validity_status', 'unknown')}"
        else:
            header = f"[{i}] doc_id={p.get('doc_id')} date={p.get('decision_date')}"
        lines.append(header)
        lines.append(str(p.get("text", ""))[:2000])
        lines.append("")
    return "\n".join(lines).strip()


def user_plre(row: dict[str, Any], passages: list[dict[str, Any]], include_validity: bool) -> str:
    return (
        f"product_attribute: {row['product_attribute']}\n"
        f"risk_theory: {row['risk_theory']}\n"
        f"query_date: {row['query_date']}\n\n"
        f"passages:\n{format_passages(passages, include_validity=include_validity)}"
    )

# ---------------------------------------------------------------------------
# IO helpers
# ---------------------------------------------------------------------------

def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open() as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def append_jsonl(path: Path, rec: dict) -> None:
    with path.open("a") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def existing_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    ids = set()
    with path.open() as f:
        for line in f:
            if line.strip():
                ids.add(json.loads(line)["pair_id"])
    return ids

# ---------------------------------------------------------------------------
# Infer
# ---------------------------------------------------------------------------

def filter_passages(passages: list[dict], system: str) -> list[dict]:
    if system == "vigil_full":
        return [p for p in passages if p.get("validity_status") != "closed"]
    return passages


def date_filter_passages(row: dict) -> list[dict]:
    tq = str(row["query_date"])
    return [p for p in row.get("passages", []) if str(p.get("decision_date", "")) <= tq]


def run_one_infer(row: dict, system: str, seed: int) -> dict:
    include_validity = True
    system_prompt = SYSTEM_PLRE
    if system == "date_filter":
        passages = date_filter_passages(row)
        include_validity = False
        system_prompt = SYSTEM_PLRE_DATE_ONLY
    else:
        passages = filter_passages(row.get("passages", []), system)

    obj = chat_json(system_prompt, user_plre(row, passages, include_validity), TEMP_CTRL, seed)
    usage = obj.pop("_usage", {})
    return {
        "experiment": "plre_infer",
        "system": system,
        "pair_id": row["pair_id"],
        "dispute_id": row.get("dispute_id"),
        "seed": seed,
        "gold": str(row["gold"]).upper(),
        "pred": extract_label(obj),
        "confidence": obj.get("confidence"),
        "stale_cited": bool(obj.get("stale_cited", False)),
        "is_stale_distractor": bool(row.get("is_stale_distractor", False)),
        "supporting_doc_ids": obj.get("supporting_doc_ids"),
        "n_passages_used": len(passages),
        **usage,
    }


def cmd_infer(args: argparse.Namespace) -> None:
    rows = load_jsonl(args.input)
    if args.limit > 0:
        rows = rows[: args.limit]
    systems = [s.strip() for s in args.systems.split(",") if s.strip()]
    for system in systems:
        for seed in SEEDS:
            out_path = OUT_DIR / f"preds_{system}_seed{seed}.jsonl"
            done = existing_ids(out_path)
            for row in tqdm(rows, desc=f"{system} seed={seed}"):
                if row["pair_id"] in done:
                    continue
                append_jsonl(out_path, run_one_infer(row, system, seed))
            print(f"Wrote {out_path}")

# ---------------------------------------------------------------------------
# B5
# ---------------------------------------------------------------------------

def run_b5(row: dict, seed: int) -> dict:
    passages = row.get("passages", [])
    system = SYSTEM_B5.format(max_iters=B5_MAX_ITERS)
    history = []
    total_out = 0
    last: dict = {}
    for it in range(1, B5_MAX_ITERS + 1):
        user = (
            f"Iteration {it}/{B5_MAX_ITERS}\n"
            f"product_attribute: {row['product_attribute']}\n"
            f"risk_theory: {row['risk_theory']}\n"
            f"query_date: {row['query_date']}\n\n"
            f"passages (ungated):\n{format_passages(passages, include_validity=False)}\n\n"
        )
        if history:
            user += "Previous draft:\n" + json.dumps(history[-1], ensure_ascii=False) + "\n"
        user += "Produce updated JSON decision."
        obj = chat_json(system, user, TEMP_CTRL, seed + it)
        usage = obj.pop("_usage", {})
        total_out += int(usage.get("tokens_out") or 0)
        last = obj
        history.append({"iteration": it, "draft": obj, "usage": usage})
        if B5_MAX_TOKENS and total_out >= B5_MAX_TOKENS:
            break
    return {
        "experiment": "b5_plre",
        "system": "b5",
        "pair_id": row["pair_id"],
        "dispute_id": row.get("dispute_id"),
        "seed": seed,
        "gold": str(row["gold"]).upper(),
        "pred": extract_label(last),
        "confidence": last.get("confidence"),
        "stale_cited": bool(last.get("stale_cited", False)),
        "is_stale_distractor": bool(row.get("is_stale_distractor", False)),
        "iterations_used": last.get("iterations_used", len(history)),
        "tokens_out_total": total_out,
        "history": history,
    }


def cmd_b5(args: argparse.Namespace) -> None:
    rows = load_jsonl(args.input)
    if args.limit > 0:
        rows = rows[: args.limit]
    for seed in SEEDS:
        out_path = OUT_DIR / f"preds_b5_seed{seed}.jsonl"
        done = existing_ids(out_path)
        for row in tqdm(rows, desc=f"b5 seed={seed}"):
            if row["pair_id"] in done:
                continue
            append_jsonl(out_path, run_b5(row, seed))
        print(f"Wrote {out_path}")

# ---------------------------------------------------------------------------
# Regex prep
# ---------------------------------------------------------------------------
NEG = re.compile(r"\b(overruled|superseded|abrogated|overturned|no longer good law)\b", re.I)


def cmd_regex_prep(args: argparse.Namespace) -> None:
    with args.input.open() as fin, args.output.open("w") as fout:
        for line in fin:
            if not line.strip():
                continue
            row = json.loads(line)
            new_ps = []
            for p in row.get("passages", []):
                p = dict(p)
                p["validity_status"] = "closed" if NEG.search(str(p.get("text", ""))) else (p.get("validity_status") or "open")
                new_ps.append(p)
            row["passages"] = new_ps
            fout.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"Wrote {args.output}")

# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def prf(y_true: list[str], y_pred: list[str]) -> tuple[float, float, float]:
    yt = [1 if y == "YES" else 0 for y in y_true]
    yp = [1 if y == "YES" else 0 for y in y_pred]
    return (
        float(precision_score(yt, yp, zero_division=0)),
        float(recall_score(yt, yp, zero_division=0)),
        float(f1_score(yt, yp, zero_division=0)),
    )


def summarize(rows: list[dict], label: str) -> None:
    if not rows:
        print(f"[{label}] empty")
        return
    p, r, f = prf([x["gold"] for x in rows], [x["pred"] for x in rows])
    stale = float(np.mean([1.0 if x.get("stale_cited") else 0.0 for x in rows]))
    print(f"[{label}] n={len(rows)}  P={p:.3f} R={r:.3f} F1={f:.3f}  stale_cite={stale:.3f}")


def paired_bootstrap_f1_delta(rows_a: list[dict], rows_b: list[dict], n_boot: int = 10_000, seed: int = 0):
    by_a = {r["pair_id"]: r for r in rows_a}
    by_b = {r["pair_id"]: r for r in rows_b}
    ids = sorted(set(by_a) & set(by_b))
    ya = np.array([1 if by_a[i]["gold"] == "YES" else 0 for i in ids])
    pa = np.array([1 if by_a[i]["pred"] == "YES" else 0 for i in ids])
    pb = np.array([1 if by_b[i]["pred"] == "YES" else 0 for i in ids])

    def _f1(y, p):
        tp = np.sum((y == 1) & (p == 1))
        fp = np.sum((y == 0) & (p == 1))
        fn = np.sum((y == 1) & (p == 0))
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        return 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0

    delta = _f1(ya, pa) - _f1(ya, pb)
    rng = np.random.default_rng(seed)
    n = len(ids)
    boots = [_f1(ya[idx], pa[idx]) - _f1(ya[idx], pb[idx]) for idx in (rng.integers(0, n, size=n) for _ in range(n_boot))]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return float(delta), float(lo), float(hi)


def cmd_metrics(args: argparse.Namespace) -> None:
    pred_dir = Path(args.pred_dir)
    paths = sorted(pred_dir.glob("preds_*.jsonl"))
    if not paths:
        raise SystemExit(f"No preds_*.jsonl under {pred_dir}")
    rows = []
    for p in paths:
        rows.extend(load_jsonl(p))
    systems = sorted({r["system"] for r in rows})
    print("Systems:", systems)
    for s in systems:
        sel = [r for r in rows if r["system"] == s and r.get("seed") == args.seed]
        summarize(sel, s)
        sub = [r for r in sel if not r.get("is_stale_distractor")]
        summarize(sub, f"{s}/non_distractor")

    def sel(system: str):
        return [r for r in rows if r["system"] == system and r.get("seed") == args.seed]

    pairs = [("vigil_full", "vigil_no_gate"), ("vigil_full", "b5"), ("vigil_full", "date_filter")]
    for a, b in pairs:
        if a in systems and b in systems:
            d, lo, hi = paired_bootstrap_f1_delta(sel(a), sel(b), n_boot=args.n_boot)
            print(f"F1({a})-F1({b}) = {d:.3f}  95% CI [{lo:.3f}, {hi:.3f}]")

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="PLRE re-experiment toolkit (all-in-one)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_inf = sub.add_parser("infer")
    p_inf.add_argument("--input", type=Path, default=DATA_DIR / "plre_test.jsonl")
    p_inf.add_argument("--systems", default="vigil_full,vigil_no_gate")
    p_inf.add_argument("--limit", type=int, default=0)
    p_inf.set_defaults(func=cmd_infer)

    p_b5 = sub.add_parser("b5")
    p_b5.add_argument("--input", type=Path, default=DATA_DIR / "plre_test.jsonl")
    p_b5.add_argument("--limit", type=int, default=0)
    p_b5.set_defaults(func=cmd_b5)

    p_rx = sub.add_parser("regex-prep")
    p_rx.add_argument("--input", type=Path, required=True)
    p_rx.add_argument("--output", type=Path, required=True)
    p_rx.set_defaults(func=cmd_regex_prep)

    p_m = sub.add_parser("metrics")
    p_m.add_argument("--pred-dir", type=Path, default=OUT_DIR)
    p_m.add_argument("--seed", type=int, default=0)
    p_m.add_argument("--n-boot", type=int, default=10_000)
    p_m.set_defaults(func=cmd_metrics)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
